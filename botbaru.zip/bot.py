import discord
from discord.ext import commands
import asyncio
import config

# Intents
intents = discord.Intents.default()
intents.members = True
intents.message_content = True

# Bot Class
class MyBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix="!", intents=intents)

    async def setup_hook(self):
        await self.load_extension("cogs.autorole")
        await self.load_extension("cogs.polling")
        await self.load_extension("cogs.leveling")
        await self.load_extension("cogs.moderasi")
        await self.load_extension("cogs.anime_notify")
        await self.load_extension("cogs.komiku_notify")
        await self.load_extension("cogs.anonymous")
        await self.load_extension("cogs.music")
        await self.load_extension("cogs.welcome_leave")
        await self.load_extension("cogs.reload")
        await self.load_extension("cogs.herobuild")

        await self.tree.sync()
        print("Semua Slash Command sudah sync!")

# Jalankan bot
bot = MyBot()

import random

async def change_status_loop():
    await bot.wait_until_ready()
    statuses = [
        discord.Activity(type=discord.ActivityType.watching, name="Welcome To"),
        discord.Activity(type=discord.ActivityType.playing, name="BOT Ga jelas"),
        discord.Activity(type=discord.ActivityType.listening, name="Cuman Iseng🤡"),
        discord.Activity(type=discord.ActivityType.watching, name="Heheheh")
    ]
    while not bot.is_closed():
        current_status = random.choice(statuses)
        await bot.change_presence(status=discord.Status.online, activity=current_status)
        await asyncio.sleep(15)  # Ganti status tiap 30 detik
        

@bot.event
async def on_ready():
    print(f"Bot {bot.user} aktif!")

bot.run(config.TOKEN)
