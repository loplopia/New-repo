import discord
from discord.ext import commands
import json
import os

LEVELS_FILE = "data/levels.json"

class Leveling(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.data = self.load_data()

    def load_data(self):
        if os.path.isfile(LEVELS_FILE):
            with open(LEVELS_FILE, "r") as f:
                return json.load(f)
        return {}

    def save_data(self):
        with open(LEVELS_FILE, "w") as f:
            json.dump(self.data, f, indent=4)

    def add_xp(self, user_id):
        user_id = str(user_id)
        if user_id not in self.data:
            self.data[user_id] = {"xp": 0, "level": 1}

        self.data[user_id]["xp"] += 10
        xp = self.data[user_id]["xp"]
        level = self.data[user_id]["level"]
        next_level = level * 100

        if xp >= next_level:
            self.data[user_id]["level"] += 1
            self.save_data()
            return True, self.data[user_id]["level"]
        self.save_data()
        return False, level

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return

        leveled_up, level = self.add_xp(message.author.id)
        if leveled_up:
            await message.channel.send(f"**Selamat {message.author.mention}, kamu naik ke Level {level}!**")

async def setup(bot):
    await bot.add_cog(Leveling(bot))
