import discord
from discord.ext import commands, tasks
import aiohttp
import config

class AnimeNotifier(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.notified = set()  # Simpan ID anime yang sudah dikirim
        self.check_anime.start()

    @tasks.loop(minutes=30)  # Cek setiap 30 menit
    async def check_anime(self):
        async with aiohttp.ClientSession() as session:
            async with session.get('https://api.jikan.moe/v4/seasons/now') as response:
                if response.status == 200:
                    data = await response.json()
                    for anime in data['data']:
                        mal_id = anime['mal_id']
                        title = anime['title']
                        if mal_id not in self.notified:
                            await self.send_anime_notification(title, anime['url'], anime['images']['jpg']['image_url'])
                            self.notified.add(mal_id)

    async def send_anime_notification(self, title, url, image):
        channel = self.bot.get_channel(config.ANIME_CHANNEL_ID)
        if channel:
            embed = discord.Embed(
                title=f"Episode Baru: {title}",
                description=f"[Tonton di MAL]({url})",
                color=discord.Color.purple()
            )
            embed.set_thumbnail(url=image)
            await channel.send(embed=embed)

async def setup(bot):
    await bot.add_cog(AnimeNotifier(bot))
