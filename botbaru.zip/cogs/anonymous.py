import discord
from discord import app_commands
from discord.ext import commands

class Anonymous(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="anon", description="Kirim pesan anonim ke channel anonymous!")
    @app_commands.describe(pesan="Pesan yang ingin kamu kirim secara anonim.")
    async def anon(self, interaction: discord.Interaction, pesan: str):
        channel_id = 123456789012345678  # ganti dengan ID channel anonymous kamu
        target_channel = self.bot.get_channel(channel_id)

        if target_channel:
            await target_channel.send(f"**Anon:** {pesan}")
            await interaction.response.send_message("Pesan kamu telah dikirim secara anonim!", ephemeral=True)
        else:
            await interaction.response.send_message("Channel anonymous tidak ditemukan.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Anonymous(bot))
