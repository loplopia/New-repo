import discord
from discord import app_commands
from discord.ext import commands

class Moderasi(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="kick", description="Kick member dari server.")
    @app_commands.describe(user="Pilih member yang ingin di-kick", reason="Alasan kick")
    async def kick(self, interaction: discord.Interaction, user: discord.Member, reason: str = "Tidak ada alasan"):
        await user.kick(reason=reason)
        await interaction.response.send_message(f"{user} telah di-kick! Alasan: {reason}")

    @app_commands.command(name="ban", description="Ban member dari server.")
    @app_commands.describe(user="Pilih member yang ingin di-ban", reason="Alasan ban")
    async def ban(self, interaction: discord.Interaction, user: discord.Member, reason: str = "Tidak ada alasan"):
        await user.ban(reason=reason)
        await interaction.response.send_message(f"{user} telah di-ban! Alasan: {reason}")

    @app_commands.command(name="unban", description="Unban user dari server.")
    @app_commands.describe(username="Contoh: NamaUser#0001")
    async def unban(self, interaction: discord.Interaction, username: str):
        banned_users = await interaction.guild.bans()
        for ban_entry in banned_users:
            user = ban_entry.user
            if f"{user.name}#{user.discriminator}" == username:
                await interaction.guild.unban(user)
                await interaction.response.send_message(f"{username} telah di-unban!")
                return
        await interaction.response.send_message(f"{username} tidak ditemukan di daftar ban!")

    @app_commands.command(name="clear", description="Hapus sejumlah pesan di channel.")
    @app_commands.describe(jumlah="Jumlah pesan yang ingin dihapus")
    async def clear(self, interaction: discord.Interaction, jumlah: int):
        await interaction.channel.purge(limit=jumlah + 1)  # +1 buat hapus command
        await interaction.response.send_message(f"{jumlah} pesan telah dihapus.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Moderasi(bot))
