import discord
from discord.ext import commands
import config

class AutoRole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        guild = member.guild

        # === Auto Role ===
        role = guild.get_role(config.AUTO_ROLE_ID)
        if role:
            await member.add_roles(role)
            print(f"[+] {member} diberi role '{role.name}'.")

        # === Welcome Message ===
        channel = guild.get_channel(config.WELCOME_CHANNEL_ID)
        if channel:
            embed = discord.Embed(
                title="Selamat Datang!",
                description=f"Welcome {member.mention} ke **{guild.name}**!\nJangan lupa cek rules ya~",
                color=discord.Color.green()
            )
            embed.set_thumbnail(url=config.WELCOME_THUMBNAIL)  # pakai link dari config
            await channel.send(embed=embed)

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        guild = member.guild
        channel = guild.get_channel(config.WELCOME_CHANNEL_ID)
        if channel:
            embed = discord.Embed(
                title="Sampai Jumpa!",
                description=f"**{member.name}** telah meninggalkan server.",
                color=discord.Color.red()
            )
            embed.set_thumbnail(url=config.LEAVE_THUMBNAIL)  # pakai link dari config
            await channel.send(embed=embed)

async def setup(bot):
    await bot.add_cog(AutoRole(bot))
