import discord
from discord.ext import commands
import config

class WelcomeLeave(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member):
        channel = self.bot.get_channel(config.WELCOME_CHANNEL_ID)
        if channel:
            embed = discord.Embed(
                title=f"Selamat Datang, {member.name}!",
                description=f"Selamat bergabung di {member.guild.name}!\nAyo kenalan, {member.mention}!",
                color=discord.Color.green()
            )
            embed.set_thumbnail(url=member.display_avatar.url)
            embed.set_image(url=config.WELCOME_GIF)  # Pakai link dari config.py
            await channel.send(embed=embed)

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        channel = self.bot.get_channel(config.LEAVE_CHANNEL_ID)
        if channel:
            embed = discord.Embed(
                title=f"Selamat Tinggal, {member.name}!",
                description=f"{member.name} telah keluar dari server.",
                color=discord.Color.red()
            )
            embed.set_thumbnail(url=member.display_avatar.url)
            embed.set_image(url=config.LEAVE_GIF)  # Pakai link dari config.py
            await channel.send(embed=embed)

async def setup(bot):
    await bot.add_cog(WelcomeLeave(bot))
    