import discord
from discord import app_commands
from discord.ext import commands

class Reload(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="reload", description="Reload ulang cogs tanpa matikan bot")
    @app_commands.checks.has_permissions(administrator=True)  # hanya admin
    async def reload(self, interaction: discord.Interaction, cog: str):
        try:
            await self.bot.unload_extension(f"cogs.{cog}")
            await self.bot.load_extension(f"cogs.{cog}")
            await interaction.response.send_message(f"✅ `{cog}` berhasil di-reload!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error saat reload `{cog}`:\n```{e}```", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Reload(bot))
