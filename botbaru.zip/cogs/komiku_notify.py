import discord
from discord.ext import commands, tasks
import aiohttp
from bs4 import BeautifulSoup
import config

class KomikuNotifier(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.notified = set()
        self.check_komiku.start()

    @tasks.loop(minutes=30)  # Cek setiap 30 menit
    async def check_komiku(self):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get("https://komiku.id/") as resp:
                    if resp.status == 200:
                        html = await resp.text(encoding=None)  # Auto-detect encoding
                        soup = BeautifulSoup(html, 'html.parser')
                        komik_list = soup.select(".daftar .bge")

                        for komik in komik_list:
                            title = komik.select_one("h3").get_text(strip=True)
                            link = komik.select_one("a")["href"]

                            if link not in self.notified:
                                await self.send_notif(title, link)
                                self.notified.add(link)
                    else:
                        print(f"[Komiku] Status error: {resp.status}")
        except Exception as e:
            print(f"[Komiku] Error saat fetch data: {e}")

    async def send_notif(self, title, url):
        channel = self.bot.get_channel(config.KOMIKU_CHANNEL_ID)
        if channel:
            embed = discord.Embed(
                title=f"Update Manga: {title}",
                description=f"Chapter baru tersedia!\n[Baca di sini]({url})",
                color=discord.Color.orange()
            )
            await channel.send(embed=embed)

async def setup(bot):
    await bot.add_cog(KomikuNotifier(bot))
