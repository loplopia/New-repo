import discord
from discord.ext import commands
import asyncio

class Music(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='join')
    async def join(self, ctx):
        if ctx.author.voice:
            channel = ctx.author.voice.channel
            await channel.connect()
            await ctx.send(f"Bot join ke {channel}!")
        else:
            await ctx.send("Kamu harus join voice channel dulu!")

    @commands.command(name='play')
    async def play(self, ctx, url: str):
        voice = discord.utils.get(self.bot.voice_clients, guild=ctx.guild)
        if not voice:
            await ctx.invoke(self.bot.get_command('join'))

        voice = discord.utils.get(self.bot.voice_clients, guild=ctx.guild)

        source = await discord.FFmpegOpusAudio.from_probe(url)
        voice.play(source)
        await ctx.send(f"Sedang memutar: {url}")

    @commands.command(name='leave')
    async def leave(self, ctx):
        voice = discord.utils.get(self.bot.voice_clients, guild=ctx.guild)
        if voice:
            await voice.disconnect()
            await ctx.send("Bot keluar dari voice channel.")
        else:
            await ctx.send("Bot tidak sedang di voice channel.")

async def setup(bot):
    await bot.add_cog(Music(bot))
