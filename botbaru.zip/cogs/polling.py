import discord
from discord.ext import commands

class Polling(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def poll(self, ctx, *, question):
        message = await ctx.send(f"**POLL:** {question}")
        await message.add_reaction("✅")
        await message.add_reaction("❌")

async def setup(bot):
    await bot.add_cog(Polling(bot))
