import discord
from discord import app_commands
from discord.ext import commands

class HeroBuild(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.builds = {
            "lu ban no.7": {
                "items": [
                    "Swift Boots", "Shadow Axe", "Bloodthirsty Bow", 
                    "Pure Sky", "Dawn Breaker", "Apocalypse"
                ],
                "thumbnail": "https://your-image-link.com/luban7.png",
                "build_image": "https://your-image-link.com/luban7_build.png"
            },
            "mulan": {
                "items": [
                    "Boots of Resistance", "Master Sword", 
                    "Spikemail", "Ominous Premonition", 
                    "Bloodthirsty Bow", "Sage’s Sanctuary"
                ],
                "thumbnail": "https://your-image-link.com/mulan.png",
                "build_image": "https://your-image-link.com/mulan_build.png"
            }
        }

    @app_commands.command(name="build", description="Cek build rekomendasi hero Honor of Kings!")
    @app_commands.describe(hero="Nama hero yang ingin kamu cek build-nya")
    async def build(self, interaction: discord.Interaction, hero: str):
        hero_lower = hero.lower()
        data = self.builds.get(hero_lower)

        if data:
            embed = discord.Embed(
                title=f"Build Rekomendasi untuk {hero.title()}",
                description="\n".join(f"{i+1}. {item}" for i, item in enumerate(data['items'])),
                color=discord.Color.green()
            )
            embed.set_thumbnail(url=data['thumbnail'])
            embed.set_image(url=data['build_image'])
            await interaction.response.send_message(embed=embed)
        else:
            await interaction.response.send_message(
                f"Hero **{hero}** belum ada di database! Coba hero lain ya.",
                ephemeral=True
            )

async def setup(bot):
    await bot.add_cog(HeroBuild(bot))
